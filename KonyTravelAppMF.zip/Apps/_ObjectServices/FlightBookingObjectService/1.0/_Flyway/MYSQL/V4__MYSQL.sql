ALTER TABLE `BookingObject`
	MODIFY `flight_logo` VARCHAR(100);
