//Type your code here
KMSPROP = {		
  ksId : "",
  senderID :"263938735785",
  //senderID :"16319371753",
  appId:"fc0a09ad-f114-48ea-99d2-355a01069a40" 
};

function displayPush(msg){
  //Defining basicConf parameter for alert
  var basicConf = {
    message: msg["content"],
    alertType: constants.ALERT_TYPE_INFO,
    alertTitle:msg["title"],"alertIcon": "conf.png"
  };
  //Defining pspConf parameter for alert
  var pspConf = {};
  //Alert definition
  kony.ui.Alert(basicConf,pspConf);
  
}
