define(function () {
   
    return {
        /**
         * @function add
         *
         * @param a 
         * @param b 
         */
        add : function (a, b) {
          return a+b;
        }      
    };
});