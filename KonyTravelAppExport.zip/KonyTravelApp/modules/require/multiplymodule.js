define(function () {
   
    return {
        /**
         * @function multiply
         *
         * @param a 
         * @param b 
         */
        multiply : function (a, b) {
          return a*b;
        }
    };
});