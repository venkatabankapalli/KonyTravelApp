define(["require\multiply"],function () {
   
    return {
        /**
         * @function square
         *
         * @param a 
         * @param b 
         */
        square : function (a) {
          multiply (a,a);
        }
    };
});