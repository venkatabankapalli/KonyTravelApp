define(function () {
   
    return {
      	/**
         * @function subtract
         *
         * @param a 
         * @param b 
         */
        subtract : function (a, b) {
          return a-b;
        }
    };
});