define(function () {
   
    return {
        /**
         * @function divide
         *
         * @param a 
         * @param b 
         */
        divide : function (a, b) {
          return a/b;
        }
    };
});