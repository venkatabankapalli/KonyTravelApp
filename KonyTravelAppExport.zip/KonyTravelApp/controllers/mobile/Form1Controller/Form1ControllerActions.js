define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_ge77fa7c7d524e379e3d812132651671: function AS_Button_ge77fa7c7d524e379e3d812132651671(eventobject) {
        var self = this;
        this.performSquare();
    }
});