define({ 

  //Type your controller code here 
  squaremodule : require("require\square"),
  
  /**
   * @function performSquare
   *
   */
  performSquare : function () {
    alert (squaremodule.square(2));
  }
});