define({ 

  //Type your controller code here 
  flightObj:{},
  
  /**
   * @function slidingMenuItemClickCallback
   * 
   * This function will be invoked when a menu item is clicked in the sliding menu. 
   * This function is associated to onMenuItemClick action of slidingmenu component.
   * This function will navigate the user to respective form based on the index of the clicked menu item.
   *
   * @param indexOfTheClickedMenuItem 
   */
  onMenuItemClickCallback : function (indexOfTheClickedMenuItem) {

    var formName = "";
    if (0 === indexOfTheClickedMenuItem[0]) {
      formName = "frmTrip";
    } else if (1 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindFlight";
    } else if (2 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindHotel";
    } else if (3 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindCar";
    } else if (4 === indexOfTheClickedMenuItem[0]) {
      formName = "frmPackage";
    } else if (5 === indexOfTheClickedMenuItem[0]) {
      formName = "frmInspireMe";
    }
    var navigationObject = new kony.mvc.Navigation(formName);
    navigationObject.navigate();
  },
  
  /**
   * @function
   *
   */
  onNavigate : function (data) {
    if(data === null || data === undefined) {
      return;
    }

    this.flightObj=data;
    var source=data["source"];
    var destination=data["destination"];
    var logo=data["flightLogo"];

    this.view.slidingmenu.flxTargetContainer.lblOnwardsSource.text=data.outbound.flights[0].origin.airport;
    this.view.slidingmenu.flxTargetContainer.lblOnwardsDestination.text=data.outbound.flights[0].destination.airport;
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyDate.text=this.getReadableDate(data.outbound.flights[0].departs_at);
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyTotalTime.text=data.outbound.duration;
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyNumberOfStops.text="Non Stop";
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyStartingTime.text=this.getTime(data.outbound.flights[0].departs_at);
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyStartingDate.text=this.getReadableDate(data.outbound.flights[0].departs_at);
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyDuration.text=data.outbound.duration;
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyArrivalTime.text=this.getTime(data.outbound.flights[0].arrives_at);
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyArrivalDate.text=this.getReadableDate(data.outbound.flights[0].arrives_at);
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneySourceAirportName.text=source["label"];
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneySourceCity.text="";
    this.view.slidingmenu.flxTargetContainer.imgOnwardsJourneyAirlinesIcon.src=logo;
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyAirlinesName.text=data.airline;
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyDestinationAirportName.text=destination["label"];
    this.view.slidingmenu.flxTargetContainer.lblOnwardsJourneyDestinationCity.text="";
    this.view.slidingmenu.flxTargetContainer.lblPrice.text=data.fare.currency+" "+data.fare.price_per_adult.total_fare;
    this.view.slidingmenu.flxTargetContainer.lblPassNo.text="For 1 Traveller";

    if(data.inbound === null || data.inbound === undefined) {
      this.view.slidingmenu.flxTargetContainer.flxReturnRoute.setVisibility(false);
      this.view.slidingmenu.flxTargetContainer.flxReturnDetails.setVisibility(false);
      return;
    }

    this.view.slidingmenu.flxTargetContainer.lblReturnSource.text=data.inbound.flights[0].origin.airport;
    this.view.slidingmenu.flxTargetContainer.lblReturnDestination.text=data.inbound.flights[0].destination.airport;
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyDate.text=this.getReadableDate(data.inbound.flights[0].departs_at);
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyTotalTime.text=data.inbound.duration;
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyNumberOfStops.text="Non Stop";
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyStartingTime.text=this.getTime(data.inbound.flights[0].departs_at);
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyStartingDate.text=this.getReadableDate(data.inbound.flights[0].departs_at);
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyDuration.text=data.inbound.duration;
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyArrivalTime.text=this.getTime(data.inbound.flights[0].arrives_at);
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyArrivalDate.text=this.getReadableDate(data.inbound.flights[0].arrives_at);
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneySourceAirportName.text=destination["label"];
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneySourceCity.text="";
    this.view.slidingmenu.flxTargetContainer.imgReturnJourneyAirlinesIcon.src=logo;
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyAirlinesName.text=data.airline;
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyDestinationAirportName.text=source["label"];
    this.view.slidingmenu.flxTargetContainer.lblReturnJourneyDestinationCity.text="";
  },

  /**
   * @function getReadableDate
   *
   * Utility function to get the readable date from a date string
   *
   */
  getReadableDate : function(dateString){
    var d = new Date(dateString);
    dateString = d.toDateString();
    return dateString;
  },
  
  /**
   * @function getTime
   *
   * Utility function to get the time from a time string
   *
   */
  getTime : function(timeString){
    var str="";
    var date1=new Date(timeString);
    var time=date1.toLocaleTimeString();
    time=(time.split(" "))[0];
    time=time.split(":");
    var hr=time[0];
    var min=time[1];
    if(hr>12){
      hr=hr%12;
      str="PM";
    }else{
      str="AM";
    }
    timeString=hr+":"+min+" "+str;
    return timeString;
  },

  /**
   * @function
   *
   */
  travellerDetails : function() {
    try{
      var navObj=new kony.mvc.Navigation("frmFlightBooking");
      navObj.navigate(this.flightObj);
    }catch(excp){
      kony.print("#### exception occured while navigating to frmFlightBooking ####"+JSON.stringify(excp));
    }
  },  

 });