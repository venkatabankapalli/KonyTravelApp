define({ 

  //Type your controller code here 
  numberOfAdultsSelectedInFlightSearchScreen:0,
  numberOfChildrenSelectedInFlightSearchScreen:0,
  numberOfInfantsSelectedInFlightSearchScreen:0,
  flightObj:{},
  
  /**
   * @function
   *
   */
  onNavigate : function (data) {
    if(data === null || data === undefined) {
      return;
    }
	
    this.flightObj=data;
    var source=data.source;
    var destination=data.destination;
    var logo=data.flightLogo;

    this.view.lblOnwardsSource.text=data.outbound.flights[0].origin.airport;
    this.view.lblOnwardsDestination.text=data.outbound.flights[0].destination.airport;
    this.view.lblOnwardsJourneyDate.text=this.getReadableDate(data.outbound.flights[0].departs_at);
    this.view.lblOnwardsJourneyTotalTime.text=data.outbound.duration;
    this.view.lblOnwardsJourneyNumberOfStops.text="Non Stop";
    this.numberOfAdultsSelectedInFlightSearchScreen=data.numberOfAdultPassengers;
    this.numberOfChildrenSelectedInFlightSearchScreen=data.numberOfChildPassengers;
    this.numberOfInfantsSelectedInFlightSearchScreen=data.numberOfInfantPassengers;
    var totalNumberOfTravellers=this.numberOfAdultsSelectedInFlightSearchScreen+this.numberOfChildrenSelectedInFlightSearchScreen+this.numberOfInfantsSelectedInFlightSearchScreen;
    this.view.lblPassNo.text="For "+totalNumberOfTravellers+" travellers";
    this.view.lblPrice.text="USD "+data.fare.total_price;
  },
  
  getReadableDate:function(dateString){
    var d = new Date(dateString);
    dateString = d.toDateString();
    return dateString;
  },
  
  /**
   * @function addAdultTravellers
   *
   * This function will dynamically add the textboxes to take the names of adult travellers
   *
   */
  addAdultTravellers : function() {
    if (this.numberOfAdultsSelectedInFlightSearchScreen === null || 
        this.numberOfAdultsSelectedInFlightSearchScreen === undefined || 
        this.numberOfAdultsSelectedInFlightSearchScreen === 0) {
      this.view.tabPaneTravellers.tabAdult.setVisibility(false);
      return;
    }
    for (i=1;i<=this.numberOfAdultsSelectedInFlightSearchScreen;i++) {
      var tbxAdult = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "top": "5dp",
        "height": "35dp",
        "width": "95%",
        "id": "tbxAdult"+i,
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "Name",
        "secureTextEntry": false,
        "skin": "sknTbx2",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "zIndex": 1
      }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
      }, {
        "autoCorrect": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
      });
      this.view.tabPaneTravellers.flxScrollAdultsList.add(tbxAdult);
    }
  },
   
  /**
   * @function addChildTravellers
   *
   * This function will dynamically add the textboxes to take the names of child travellers
   *
   */
  addChildTravellers : function() {
    if (this.numberOfChildrenSelectedInFlightSearchScreen === null || 
        this.numberOfChildrenSelectedInFlightSearchScreen === undefined || 
        this.numberOfChildrenSelectedInFlightSearchScreen === 0) {
      this.view.tabPaneTravellers.tabChild.setVisibility(false);
      return;
    }
    for (i=1;i<=this.numberOfChildrenSelectedInFlightSearchScreen;i++) {
      var tbxChild = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "top": "5dp",
        "height": "35dp",
        "width": "95%",
        "id": "tbxChild"+i,
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "Name",
        "secureTextEntry": false,
        "skin": "sknTbx2",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "zIndex": 1
      }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
      }, {
        "autoCorrect": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
      });
      this.view.tabPaneTravellers.flxScrollChildrenList.add(tbxChild);
    }
  },
  
  /**
   * @function addInfantTravellers
   *
   * This function will dynamically add the textboxes to take the names of infant travellers
   *
   */
  addInfantTravellers : function() {
    if (this.numberOfInfantsSelectedInFlightSearchScreen === null || 
        this.numberOfInfantsSelectedInFlightSearchScreen === undefined || 
        this.numberOfInfantsSelectedInFlightSearchScreen === 0) {
      this.view.tabPaneTravellers.tabInfant.setVisibility(false);
      return;
    }
    for (i=1;i<=this.numberOfInfantsSelectedInFlightSearchScreen;i++) {
      var tbxInfant = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "top": "5dp",
        "height": "35dp",
        "width": "95%",
        "id": "tbxInfant"+i,
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "Name",
        "secureTextEntry": false,
        "skin": "sknTbx2",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "zIndex": 1
      }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
      }, {
        "autoCorrect": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
      });
      this.view.tabPaneTravellers.flxScrollInfantsList.add(tbxInfant);
    }
  },  
  
  /**
   * @function
   *
   */
  navigateToFlightBookingSummary : function () {
    var adultTravellerNames = "";
    var adultTravellersList = this.view.tabPaneTravellers.flxScrollAdultsList.widgets();
    var adultNameTextBoxID;
    if (this.numberOfAdultsSelectedInFlightSearchScreen === null || 
        this.numberOfAdultsSelectedInFlightSearchScreen === undefined || 
        this.numberOfAdultsSelectedInFlightSearchScreen === 0) {
      adultTravellerNames="No adult travellers";
    } else {
      for (i=0;i<adultTravellersList.length;i++) {
        adultNameTextBoxID=adultTravellersList[i].id;
        if(this.view[adultNameTextBoxID].text !== null && this.view[adultNameTextBoxID].text !== "") {
          if (adultTravellerNames !== "")
            adultTravellerNames = adultTravellerNames+","+this.view[adultNameTextBoxID].text;
          else
            adultTravellerNames = this.view[adultNameTextBoxID].text;
        } else {
          alert ("Please enter all the adult traveller names.");
          adultTravellerNames="";
          return;
        }
      }
      //alert(adultTravellerNames);
    }
    
    var childTravellerNames = "";
    var childTravellersList = this.view.tabPaneTravellers.flxScrollChildrenList.widgets();
    var childNameTextBoxID;
    if (this.numberOfChildrenSelectedInFlightSearchScreen === null || 
        this.numberOfChildrenSelectedInFlightSearchScreen === undefined || 
        this.numberOfChildrenSelectedInFlightSearchScreen === 0) {
      childTravellerNames="No child travellers";
    } else {
      for (i=0;i<childTravellersList.length;i++) {
        childNameTextBoxID=childTravellersList[i].id;
        if(this.view[childNameTextBoxID].text !== null && this.view[childNameTextBoxID].text !== "") {
          if (childTravellerNames !== "")
            childTravellerNames = childTravellerNames+","+this.view[childNameTextBoxID].text;
          else
            childTravellerNames = this.view[childNameTextBoxID].text;
        } else {
          alert ("Please enter all the child traveller names.");
          childTravellerNames="";
          return;
        }
      }
      //alert(childTravellerNames);
    }

    var infantTravellerNames = "";
    var infantTravellersList = this.view.tabPaneTravellers.flxScrollInfantsList.widgets();
    var infantNameTextBoxID;
    if (this.numberOfInfantsSelectedInFlightSearchScreen === null || 
        this.numberOfInfantsSelectedInFlightSearchScreen === undefined || 
        this.numberOfInfantsSelectedInFlightSearchScreen === 0) {
      infantTravellerNames="No infant travellers";
    } else {
      for (i=0;i<infantTravellersList.length;i++) {
        infantNameTextBoxID=infantTravellersList[i].id;
        if(this.view[infantNameTextBoxID].text !== null && this.view[infantNameTextBoxID].text !== "") {
          if (infantTravellerNames !== "")
            infantTravellerNames = infantTravellerNames+","+this.view[infantNameTextBoxID].text;
          else
            infantTravellerNames = this.view[infantNameTextBoxID].text;
        } else {
          alert ("Please enter all the infant traveller names.");
          infantTravellerNames="";
          return;
        }
      }
      //alert(infantTravellerNames);
    }

    this.flightObj.adultTravellerNames=adultTravellerNames;
    this.flightObj.childTravellerNames=childTravellerNames;
    this.flightObj.infantTravellerNames=infantTravellerNames;
    var navObj=new kony.mvc.Navigation("frmFlightBookingSummary");
    navObj.navigate(this.flightObj);
  }
 });