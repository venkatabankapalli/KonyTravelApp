define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_a24d38f09b2741828fca8a470d4e505c: function AS_Button_a24d38f09b2741828fca8a470d4e505c(eventobject) {
        var self = this;
        this.navigateToFlightBookingSummary();
    },
    AS_Form_ce4265f87ad14c2b802d81cf8e43db1c: function AS_Form_ce4265f87ad14c2b802d81cf8e43db1c(eventobject) {
        var self = this;
        this.addAdultTravellers();
        this.addChildTravellers();
        this.addInfantTravellers();
    }
});