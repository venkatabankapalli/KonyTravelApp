define({ 

 //Type your controller code here 
  trips:[],
  days : ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],
  allMonths : ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],

  /**
   * @function slidingMenuItemClickCallback
   * 
   * This function will be invoked when a menu item is clicked in the sliding menu. 
   * This function is associated to onMenuItemClick action of slidingmenu component.
   * This function will navigate the user to respective form based on the index of the clicked menu item.
   *
   * @param indexOfTheClickedMenuItem 
   */
  onMenuItemClickCallback : function (indexOfTheClickedMenuItem) {

    var formName = "";
    if (0 === indexOfTheClickedMenuItem[0]) {
      formName = "frmTrip";
    } else if (1 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindFlight";
    } else if (2 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindHotel";
    } else if (3 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindCar";
    } else if (4 === indexOfTheClickedMenuItem[0]) {
      formName = "frmPackage";
    } else if (5 === indexOfTheClickedMenuItem[0]) {
      formName = "frmInspireMe";
    }
    var navigationObject = new kony.mvc.Navigation(formName);
    navigationObject.navigate();
  },
  
  /**
   * @function
   *
   */
  onNavigate : function () {
    this.getBookings();
  },

  /**
   * @function
   *
   */
  getBookings : function () {
    this.view.slidingmenu.flxTargetContainer.segYourTrips.removeAll();
    this.view.slidingmenu.flxTargetContainer.segYourTrips.setVisibility(false);
    var controllerScope=this;
    var email="venkata.bankapalli@kony.com";
    try {
      kony.model.ApplicationContext.showLoadingScreen("Loading your trips ...");
      kony.model.ApplicationContext.createModel("BookingObject",
                                                "FlightBookingObjectService", 
                                                {"access": "online"},
                                                {"getFromServer":true},
                                                createBookingObjectModelSuccessCallback,
                                                createBookingObjectModeErrorCallback);
    } catch(exp){
      kony.model.ApplicationContext.dismissLoadingScreen();
      kony.print("Exception while creating data model");
    }
    
    /**
     * @function
     *
     * @param dataModel 
     */
    function createBookingObjectModelSuccessCallback (dataModel) {
      var userDataObject = new kony.sdk.dto.DataObject("BookingObject");
      var params = {};
      params.dataObject = userDataObject;
      params.queryParams = {
        "$filter": "email eq "+"'"+email+"'"
      };
      dataModel.fetch (params, 
                       /**
                        * @function
                        *
                        * @param successResponse 
                        */
                       function(successResponse) {
                        kony.model.ApplicationContext.dismissLoadingScreen();
                        var length=successResponse.length;
                        controllerScope.trips=successResponse;
                        var segObj1={};
                        var segObj2={};
                        var segArray=[];
                        controllerScope.view.slidingmenu.flxTargetContainer.segYourTrips.widgetDataMap={
                          "imgSegSectionHdr":"sectionImage",
                          "lblSegSectionHdr":"sectionlblText",
                          "lblInfo":"lblFlightInfo",
                          "lblDate":"lblFlightDate"
                        }
                        var days=controllerScope.days;
                        var allMonths=controllerScope.allMonths;
                        var source,destination;
                        var aDate;
                        var onward_departure;
                        var return_departure;
                        for(var i=0;i<length;i++){
                          source=successResponse[i].onward_source;
                          destination=successResponse[i].onward_destination;
                          aDate = new Date(successResponse[i].onward_departure);
                          onward_departure = days[aDate.getDay()]+", "+allMonths[aDate.getMonth()]+" "+aDate.getDate()+", "+aDate.getFullYear();

                          segObj1={
                            "lblFlightInfo":source+"/"+destination,
                            "lblFlightDate":onward_departure,
                            "lblId":i,
                            "lblBound":"OUTBOUND"
                          };
                          segArray.push(segObj1);

                          if(successResponse[i].return_departure=="")
                            continue;
                          aDate = new Date(successResponse[i].return_departure);
                          return_departure = days[aDate.getDay()]+", "+allMonths[aDate.getMonth()]+" "+aDate.getDate()+", "+aDate.getFullYear();

                          source=successResponse[i].return_source;
                          destination=successResponse[i].return_destination;
                          segObj2={
                            "lblFlightInfo":source+"/"+destination,
                            "lblFlightDate":return_departure,
                            "lblId":i,
                            "lblBound":"INBOUND"
                          }
                          segArray.push(segObj2);
                        }
                        var segMainArray = [];
                        var count=segArray.length;
                        if(count==0||count==1){
                          segMainArray.push({"sectionImage": "plane_icon_color.png","sectionlblText" :""+count+" Upcoming flight"});
                        }else{
                          segMainArray.push({"sectionImage": "plane_icon_color.png","sectionlblText" :""+count+" Upcoming flights"});
                        }
                        segMainArray.push(segArray);
                        var segSectionArray = [];
                        segSectionArray.push(segMainArray);
                        controllerScope.view.slidingmenu.flxTargetContainer.segYourTrips.setVisibility(true);
                        controllerScope.view.slidingmenu.flxTargetContainer.segYourTrips.setData(segSectionArray);
                      }, 
                      /**
                       * @function
                       *
                       * @param errorResponse 
                       */
                      function(errorResponse) {
                        kony.model.ApplicationContext.dismissLoadingScreen();
                        kony.print("$$$$$$$$$$$$$$$ fetch failed $$$$$$$$ "+JSON.stringify(errorResponse.getRootErrorObj()));
                        alert("Something went wrong,please try later");
                      });
    }
    /**
     * @function
     *
     * @param err 
     */
    function createBookingObjectModeErrorCallback (err) {
      kony.model.ApplicationContext.dismissLoadingScreen();
      alert("Error "+JSON.stringify(err.getRootErrorObj()));
    }
  },
  
 });