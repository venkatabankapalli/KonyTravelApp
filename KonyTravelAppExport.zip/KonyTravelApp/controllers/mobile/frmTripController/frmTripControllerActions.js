define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_UWI_eb2fedeb6a58404493dcd3365e4b876e: function AS_UWI_eb2fedeb6a58404493dcd3365e4b876e(menuindex) {
        var self = this;
        this.onMenuItemClickCallback(menuindex);
    }
});