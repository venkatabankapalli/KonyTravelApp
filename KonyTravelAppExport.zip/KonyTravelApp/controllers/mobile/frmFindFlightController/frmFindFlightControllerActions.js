define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Label_f487e3ae9fbe4e9dbe6bbb23138e1884: function AS_Label_f487e3ae9fbe4e9dbe6bbb23138e1884(eventobject, x, y) {
        var self = this;
        this.showAirportSearch(eventobject);
    },
    AS_Label_hfeaea141e8f4a81b75346fa78b1843e: function AS_Label_hfeaea141e8f4a81b75346fa78b1843e(eventobject, x, y) {
        var self = this;
        this.showAirportSearch(eventobject);
    },
    AS_Calendar_g16169efd1414787afae260dff4f83b3: function AS_Calendar_g16169efd1414787afae260dff4f83b3(eventobject, isValidDateSelected) {
        var self = this;
        this.populateReturnDatesBasedOnDepartureDateSelected();
    },
    AS_Calendar_b5e5d38fbf2e4eb09e8a36f6d606f021: function AS_Calendar_b5e5d38fbf2e4eb09e8a36f6d606f021(eventobject, isValidDateSelected) {
        var self = this;
        this.returnDateValidation();
    },
    AS_Label_b5605641489b4c76800849fd659d4a46: function AS_Label_b5605641489b4c76800849fd659d4a46(eventobject, x, y) {
        var self = this;
        this.showNumberOfPassengersSelectionLayer();
    },
    AS_Button_c9a7482b2b464fd8b4771e6c847113b3: function AS_Button_c9a7482b2b464fd8b4771e6c847113b3(eventobject) {
        var self = this;
        this.fetchAndPopulateFlights();
    },
    AS_Segment_i4450dd050e44dab903d8efc77b31ffa: function AS_Segment_i4450dd050e44dab903d8efc77b31ffa(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.onFlightSelection();
    },
    AS_TextField_hd034366b3414b6e80d439a26764ad6d: function AS_TextField_hd034366b3414b6e80d439a26764ad6d(eventobject, changedtext) {
        var self = this;
        this.fetchAndPopulateAirports(eventobject);
    },
    AS_Image_bdf9f362dc4243b193aea08d6645dfcc: function AS_Image_bdf9f362dc4243b193aea08d6645dfcc(eventobject, x, y) {
        var self = this;
        this.hideAirportSearch();
    },
    AS_Segment_ia0e4f10f06c425e8dd44afe31ea613f: function AS_Segment_ia0e4f10f06c425e8dd44afe31ea613f(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.populateSelectedAirport();
    },
    AS_Label_a265a27688c947728688fb0b8f0aa829: function AS_Label_a265a27688c947728688fb0b8f0aa829(eventobject, x, y) {
        var self = this;
        this.onAdultSelection(eventobject);
    },
    AS_Label_c4e429d174d54aa09c8166f29a801221: function AS_Label_c4e429d174d54aa09c8166f29a801221(eventobject, x, y) {
        var self = this;
        this.onAdultSelection(eventobject);
    },
    AS_Label_e40bed9ca6c54e18a3a5155f894f81cc: function AS_Label_e40bed9ca6c54e18a3a5155f894f81cc(eventobject, x, y) {
        var self = this;
        this.onAdultSelection(eventobject);
    },
    AS_Label_d681088237c84b84baa315fbc3929de1: function AS_Label_d681088237c84b84baa315fbc3929de1(eventobject, x, y) {
        var self = this;
        this.onAdultSelection(eventobject);
    },
    AS_Label_c65a2026b21d4e76bd0b18848c1d2bcf: function AS_Label_c65a2026b21d4e76bd0b18848c1d2bcf(eventobject, x, y) {
        var self = this;
        this.onAdultSelection(eventobject);
    },
    AS_Label_da06276fe8134f1f9a75384023364178: function AS_Label_da06276fe8134f1f9a75384023364178(eventobject, x, y) {
        var self = this;
        this.onAdultSelection(eventobject);
    },
    AS_Label_a9335b7286a94716b41fc350ddbcc68f: function AS_Label_a9335b7286a94716b41fc350ddbcc68f(eventobject, x, y) {
        var self = this;
        this.onChildrenSelection(eventobject);
    },
    AS_Label_b102b48c12b84dce9f35bfa67a565886: function AS_Label_b102b48c12b84dce9f35bfa67a565886(eventobject, x, y) {
        var self = this;
        this.onChildrenSelection(eventobject);
    },
    AS_Label_f119bc0eee7148c28cf1d89f8db3270a: function AS_Label_f119bc0eee7148c28cf1d89f8db3270a(eventobject, x, y) {
        var self = this;
        this.onChildrenSelection(eventobject);
    },
    AS_Label_c7169ad8b13842a5a704bdd12094acaa: function AS_Label_c7169ad8b13842a5a704bdd12094acaa(eventobject, x, y) {
        var self = this;
        this.onChildrenSelection(eventobject);
    },
    AS_Image_d6ed3e5a555a45ca85abe9e157b00c5b: function AS_Image_d6ed3e5a555a45ca85abe9e157b00c5b(eventobject, x, y) {
        var self = this;
        this.removeChildren();
    },
    AS_Label_dcf770ee958c43f793ea59d1101c85d5: function AS_Label_dcf770ee958c43f793ea59d1101c85d5(eventobject, x, y) {
        var self = this;
        this.onInfantsSelection(eventobject);
    },
    AS_Label_b60a5d66047541d1a746534cfb033cdc: function AS_Label_b60a5d66047541d1a746534cfb033cdc(eventobject, x, y) {
        var self = this;
        this.onInfantsSelection(eventobject);
    },
    AS_Label_fb317e5fe9534c269ca36ba666bec5ed: function AS_Label_fb317e5fe9534c269ca36ba666bec5ed(eventobject, x, y) {
        var self = this;
        this.onInfantsSelection(eventobject);
    },
    AS_Label_b624478c4b1347439bb102174440068d: function AS_Label_b624478c4b1347439bb102174440068d(eventobject, x, y) {
        var self = this;
        this.onInfantsSelection(eventobject);
    },
    AS_Image_b3fe035e1e8a4a47a79ad6cff36ca9ad: function AS_Image_b3fe035e1e8a4a47a79ad6cff36ca9ad(eventobject, x, y) {
        var self = this;
        this.removeInfants();
    },
    AS_Button_gb6ecb9f20ca47d984adb67f5cc5f74a: function AS_Button_gb6ecb9f20ca47d984adb67f5cc5f74a(eventobject) {
        var self = this;
        this.hideNumberOfPassengersSelectionLayer();
    },
    AS_UWI_eb2fedeb6a58404493dcd3365e4b876e: function AS_UWI_eb2fedeb6a58404493dcd3365e4b876e(menuindex) {
        var self = this;
        this.onMenuItemClickCallback(menuindex);
    }
});