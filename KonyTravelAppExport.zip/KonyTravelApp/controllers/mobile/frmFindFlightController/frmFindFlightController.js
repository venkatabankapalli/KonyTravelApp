define({ 

  //Type your controller code here 
  numberOfAdultPassengers:0,
  numberOfChildPassengers:0,
  numberOfInfantPassengers:0,
  searchForDepartureAirport:false,
  searhForReturnAirport:false,
  sourceAirport:{},
  destinationAirport:{},
  flightList:[],
  logo:"",
  airlineName:"",
  
  /**
   * @function
   *
   */
  onNavigate : function  () {
    var today = new Date();
    var todayDate=today.getDate();
    var toDayMonth=1+today.getMonth();
    var toDayYear=today.getFullYear();

    // Set TODAY as the start date to the departure calendar and return calendar.
    this.view.slidingmenu.flxTargetContainer.calDeparture.validStartDate = [todayDate,toDayMonth,toDayYear];
    this.view.slidingmenu.flxTargetContainer.calReturn.validStartDate = [todayDate,toDayMonth,toDayYear];

    this.view.slidingmenu.flxTargetContainer.segFlights.setVisibility(false);
    this.view.slidingmenu.flxTargetContainer.lblNumberOfFlights.setVisibility(false);
  },
  
  /**
   * @function slidingMenuItemClickCallback
   * 
   * This function will be invoked when a menu item is clicked in the sliding menu. 
   * This function is associated to onMenuItemClick action of slidingmenu component.
   * This function will navigate the user to respective form based on the index of the clicked menu item.
   *
   * @param indexOfTheClickedMenuItem 
   */
  onMenuItemClickCallback : function (indexOfTheClickedMenuItem) {

    var formName = "";
    if (0 === indexOfTheClickedMenuItem[0]) {
      formName = "frmTrip";
    } else if (1 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindFlight";
    } else if (2 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindHotel";
    } else if (3 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindCar";
    } else if (4 === indexOfTheClickedMenuItem[0]) {
      formName = "frmPackage";
    } else if (5 === indexOfTheClickedMenuItem[0]) {
      formName = "frmInspireMe";
    }
    var navigationObject = new kony.mvc.Navigation(formName);
    navigationObject.navigate();
  },
  
  
  /**
   * @function showAirportSearch
   * 
   * This function will be invoked on the click on From or To options in flight search screen. 
   * This function is associated to onTouchEnd action of From and To options.
   * This function will show the airport search layer.
   *
   */
  showAirportSearch : function (eventObject) {
    if ("lblFrom" === eventObject.id) {
      this.view.slidingmenu.flxTargetContainer.tbxAirport.placeholder = "Enter Source";
      this.searchForDepartureAirport = true;
      this.searhForReturnAirport = false;
    } else if ("lblTo" === eventObject.id) {
      this.view.slidingmenu.flxTargetContainer.tbxAirport.placeholder = "Enter Destination";
      this.searchForDepartureAirport = false;
      this.searhForReturnAirport = true;
    }
    
    var moveAnimation = {
      						"100": {"top": "0%", "stepConfig": {"timingFunction": kony.anim.EASE}}
    					};
    var animationObject = kony.ui.createAnimation(moveAnimation);
    var animationTimmingObject = {"delay": 0,"iterationCount": 1,"fillMode": kony.anim.FILL_MODE_FORWARDS,"duration": 0.5};
    var animationCallbackObject = {"animationEnd": function () {}};
    this.view.slidingmenu.flxTargetContainer.flexAirportSearch.animate(animationObject,animationTimmingObject,animationCallbackObject);  
  },

  /**
   * @function hideAirportSearch
   * 
   * This function will be invoked in the onTouchEnd of the back button on the airport search layer. 
   * This function will hide the airport search layer.
   *
   */
  hideAirportSearch : function () {
    var moveAnimation = {
      						"100": {"top": "100%", "stepConfig": {"timingFunction": kony.anim.EASE}}
    					};
    var animationObject = kony.ui.createAnimation(moveAnimation);
    var animationTimmingObject = {"delay": 0,"iterationCount": 1,"fillMode": kony.anim.FILL_MODE_FORWARDS,"duration": 0.5};
    var animationCallbackObject = {"animationEnd": clearAirportListFromSegment.bind(this)};
    this.view.slidingmenu.flxTargetContainer.flexAirportSearch.animate(animationObject,animationTimmingObject,animationCallbackObject);
    
    /**
     * @function clearAirportListFromSegment
     *
     */
    function clearAirportListFromSegment () {
      this.view.slidingmenu.flxTargetContainer.tbxAirport.text="";
      this.view.slidingmenu.flxTargetContainer.segAirports.removeAll();
      this.view.slidingmenu.flxTargetContainer.segAirports.setVisibility(false);
      if (this.searchForDepartureAirport) this.searchForDepartureAirport = false;
      if (this.searhForReturnAirport) this.searhForReturnAirport = false;
    }
  },
  
  
  
  /**
   * @function returnDateValidation
   * 
   * This function will be invoked in the onSelection event of return calendar.
   * In this function we validate whether departure date is selected or not.
   *
   */
  returnDateValidation : function () {
    if(this.view.slidingmenu.flxTargetContainer.calDeparture.date === null || this.view.slidingmenu.flxTargetContainer.calDeparture.date === ""){
      // TODO: There seems to be a bug in the clear API for iOS platform, need to investigate further.
      this.view.slidingmenu.flxTargetContainer.calReturn.clear();
      alert("Please select departure date before selecting return date.");
      return;
    }
  },
  
  /**
   * @function populateReturnDatesBasedOnDepartureDateSelected
   * 
   * This function will be invoked in the onSelection event of departure calendar.
   * In this function we will set the calendar for return date based on the selected departure date.
   * Return date can be any date within 1 year from the selected departure date.
   *
   */
  populateReturnDatesBasedOnDepartureDateSelected : function () {
    var selectedDepartureDate = this.view.slidingmenu.flxTargetContainer.calDeparture.date;
    var validEndDateYearForReturnCalendar = parseInt(selectedDepartureDate.split("/")[0])+1;
    var validEndDateMonthForReturnCalendar = selectedDepartureDate.split("/")[1];
    var validEndDateDayForReturnCalendar = selectedDepartureDate.split("/")[2];
    this.view.slidingmenu.flxTargetContainer.calReturn.validEndDate = [validEndDateDayForReturnCalendar, validEndDateMonthForReturnCalendar, validEndDateYearForReturnCalendar];
  },
  
  /**
   * @function showNumberOfPassengersSelectionLayer
   *
   * This function will be invoked in the onTouchEnd event of number of traveller selection label.
   * In this function we will animate the passenger selection layer into the form.
   *
   */
  showNumberOfPassengersSelectionLayer : function () {
    var moveAnimation = {
      						"100": {"top": "0%", "stepConfig": {"timingFunction": kony.anim.EASE}}
    					};
    var animationObject = kony.ui.createAnimation(moveAnimation);
    var animationTimmingObject = {"delay": 0,"iterationCount": 1,"fillMode": kony.anim.FILL_MODE_FORWARDS,"duration": 0.5};
    var animationCallbackObject = {"animationEnd": function () {}};
    this.view.slidingmenu.flxTargetContainer.flexNumberOfPassengersSelector.animate(animationObject,animationTimmingObject,animationCallbackObject);  
  },
  
  /**
   * @function hideNumberOfPassengersSelectionLayer
   *
   * This function will be invoked in the onClick event of Done button in the passenger selection layer.
   * In this function we will set the number of travellers information on find flights layer.
   * In this function we will animate the passenger selection layer out the form.
   *
   */
  hideNumberOfPassengersSelectionLayer : function () {
    var numberOfPassengersInfo = "";
    if (1<=this.numberOfAdultPassengers) {
      numberOfPassengersInfo = this.numberOfAdultPassengers + " adult";
    }
    if (1<=this.numberOfChildPassengers) {
      numberOfPassengersInfo = numberOfPassengersInfo + " , " + this.numberOfChildPassengers + " child";
    }
    if (1<=this.numberOfInfantPassengers) {
      numberOfPassengersInfo = numberOfPassengersInfo + " , " + this.numberOfInfantPassengers + " infant";
    }
    if (numberOfPassengersInfo !== "") {
      this.view.slidingmenu.flxTargetContainer.lblNumberOfPassengers.text = numberOfPassengersInfo + " travellers";
    }
    
    var moveAnimation = {
      						"100": {"top": "100%", "stepConfig": {"timingFunction": kony.anim.EASE}}
    					};
    var animationObject = kony.ui.createAnimation(moveAnimation);
    var animationTimmingObject = {"delay": 0,"iterationCount": 1,"fillMode": kony.anim.FILL_MODE_FORWARDS,"duration": 0.5};
    var animationCallbackObject = {"animationEnd": function () {}};
    this.view.slidingmenu.flxTargetContainer.flexNumberOfPassengersSelector.animate(animationObject,animationTimmingObject,animationCallbackObject);  
  },
  
  /**
   * @function onAdultSelection
   *
   * @param eventObject 
   *
   * This function will be invoked in the onTouchEnd event of labels lblAdult1 to lblAdult6.
   * In this function we will change the skin of the selected number of adults label to sknLblNumberOfPassengersSelected
   * and will reset the skin of rest of the number of adults labels to sknLblNumberOfPassengersUnSelected
   *
   */
  onAdultSelection : function (eventObject) {
    if (6<this.numberOfAdultPassengers+this.numberOfChildPassengers+this.numberOfInfantPassengers) {
      alert ("Maximum only 6 total passengers are allowed");
    } else {
      if ("lblAdult1" === eventObject.id) {
        this.numberOfAdultPassengers = 1;
        this.view.slidingmenu.flxTargetContainer.lblAdult1.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult4.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult5.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult6.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblAdult2" === eventObject.id) {
        this.numberOfAdultPassengers = 2;
        this.view.slidingmenu.flxTargetContainer.lblAdult1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult2.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult4.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult5.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult6.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblAdult3" === eventObject.id) {
        this.numberOfAdultPassengers = 3;
        this.view.slidingmenu.flxTargetContainer.lblAdult1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult3.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult4.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult5.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult6.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblAdult4" === eventObject.id) {
        this.numberOfAdultPassengers = 4;
        this.view.slidingmenu.flxTargetContainer.lblAdult1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult4.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult5.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult6.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblAdult5" === eventObject.id) {
        this.numberOfAdultPassengers = 5;
        this.view.slidingmenu.flxTargetContainer.lblAdult1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult4.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult5.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult6.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblAdult6" === eventObject.id) {
        this.numberOfAdultPassengers = 6;
        this.view.slidingmenu.flxTargetContainer.lblAdult1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult4.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult5.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblAdult6.skin = sknLblNumberOfPassengersSelected;
      }
    }
  },
  
  /**
   * @function onChildrenSelection
   *
   * @param eventObject 
   *
   * This function will be invoked in the onTouchEnd event of labels lblChild1 to lblChild4.
   * In this function we will change the skin of the selected number of children label to sknLblNumberOfPassengersSelected
   * and will reset the skin of rest of the number of children labels to sknLblNumberOfPassengersUnSelected
   *
   */
  onChildrenSelection :  function (eventObject) {
	if (0 === this.numberOfAdultPassengers) {
      alert ("Please select atleast one adult passenger");
      return;
    } else {
      if ("lblChild1" === eventObject.id) {
        this.numberOfChildPassengers = 1;
        this.view.slidingmenu.flxTargetContainer.lblChild1.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild4.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblChild2" === eventObject.id) {
        this.numberOfChildPassengers = 2;
        this.view.slidingmenu.flxTargetContainer.lblChild1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild2.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild4.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblChild3" === eventObject.id) {
        this.numberOfChildPassengers = 3;
        this.view.slidingmenu.flxTargetContainer.lblChild1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild3.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild4.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblChild4" === eventObject.id) {
        this.numberOfChildPassengers = 4;
        this.view.slidingmenu.flxTargetContainer.lblChild1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblChild4.skin = sknLblNumberOfPassengersSelected;
      }    
    }
    if (6<this.numberOfAdultPassengers+this.numberOfChildPassengers+this.numberOfInfantPassengers) {
      this.view.slidingmenu.flxTargetContainer.lblChild1.skin = sknLblNumberOfPassengersUnSelected;
      this.view.slidingmenu.flxTargetContainer.lblChild2.skin = sknLblNumberOfPassengersUnSelected;
      this.view.slidingmenu.flxTargetContainer.lblChild3.skin = sknLblNumberOfPassengersUnSelected;
      this.view.slidingmenu.flxTargetContainer.lblChild4.skin = sknLblNumberOfPassengersUnSelected;
      this.numberOfChildPassengers = 0;
      alert ("Maximum only 6 total passengers are allowed");
      return;
    }    
  },
  
  /**
   * @function onInfantsSelection
   *
   * @param eventObject 
   *
   * This function will be invoked in the onTouchEnd event of labels lblInfant1 to lblInfant4.
   * In this function we will change the skin of the selected number of infants label to sknLblNumberOfPassengersSelected
   * and will reset the skin of rest of the number of infants labels to sknLblNumberOfPassengersUnSelected
   *
   */
  onInfantsSelection : function (eventObject) {
	if (0 === this.numberOfAdultPassengers) {
      alert ("Please select atleast one adult passenger");
      return;
    } else {
      if ("lblInfant1" === eventObject.id) {
        this.numberOfInfantPassengers = 1;
        this.view.slidingmenu.flxTargetContainer.lblInfant1.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant4.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblInfant2" === eventObject.id) {
        this.numberOfInfantPassengers = 2;
        this.view.slidingmenu.flxTargetContainer.lblInfant1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant2.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant4.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblInfant3" === eventObject.id) {
        this.numberOfInfantPassengers = 3;
        this.view.slidingmenu.flxTargetContainer.lblInfant1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant3.skin = sknLblNumberOfPassengersSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant4.skin = sknLblNumberOfPassengersUnSelected;
      } else if ("lblInfant4" === eventObject.id) {
        this.numberOfInfantPassengers = 4;
        this.view.slidingmenu.flxTargetContainer.lblInfant1.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant2.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant3.skin = sknLblNumberOfPassengersUnSelected;
        this.view.slidingmenu.flxTargetContainer.lblInfant4.skin = sknLblNumberOfPassengersSelected;
      }    
    }
    if (6<this.numberOfAdultPassengers+this.numberOfChildPassengers+this.numberOfInfantPassengers) {
      this.view.slidingmenu.flxTargetContainer.lblInfant1.skin = sknLblNumberOfPassengersUnSelected;
      this.view.slidingmenu.flxTargetContainer.lblInfant2.skin = sknLblNumberOfPassengersUnSelected;
      this.view.slidingmenu.flxTargetContainer.lblInfant3.skin = sknLblNumberOfPassengersUnSelected;
      this.view.slidingmenu.flxTargetContainer.lblInfant4.skin = sknLblNumberOfPassengersUnSelected;
      this.numberOfInfantPassengers = 0;
      alert ("Maximum only 6 total passengers are allowed");
      return;
    }    
  },
  
  /**
   * @function removeChildren
   *
   * This function will be invoked in the onTouchEnd event of cross image to remove children selection.
   * In this function we will remove the children selection and make the number of children passengers as 0.
   *
   */
  removeChildren : function () {
    this.view.slidingmenu.flxTargetContainer.lblChild1.skin = sknLblNumberOfPassengersUnSelected;
    this.view.slidingmenu.flxTargetContainer.lblChild2.skin = sknLblNumberOfPassengersUnSelected;
    this.view.slidingmenu.flxTargetContainer.lblChild3.skin = sknLblNumberOfPassengersUnSelected;
    this.view.slidingmenu.flxTargetContainer.lblChild4.skin = sknLblNumberOfPassengersUnSelected;
    this.numberOfChildPassengers = 0;
  },

  /**
   * @function removeInfants
   *
   * This function will be invoked in the onTouchEnd event of cross image to remove infants selection.
   * In this function we will remove the infants selection and make the number of infant passengers as 0.
   *
   */
  removeInfants : function () {
    this.view.slidingmenu.flxTargetContainer.lblInfant1.skin = sknLblNumberOfPassengersUnSelected;
    this.view.slidingmenu.flxTargetContainer.lblInfant2.skin = sknLblNumberOfPassengersUnSelected;
    this.view.slidingmenu.flxTargetContainer.lblInfant3.skin = sknLblNumberOfPassengersUnSelected;
    this.view.slidingmenu.flxTargetContainer.lblInfant4.skin = sknLblNumberOfPassengersUnSelected;
    this.numberOfInfantPassengers = 0;
  },
  
  /**
   * @function fetchAndPopulateAirports
   * 
   * This function will be invoked in the onTextChange event of the text box to searh for filghts.
   * In this function we will invoke "Airport_Autocomplete" operation in "Amadeus" service configured in Fabric.
   * And the results are populated into the segment to show the Airports.
   *
   */
  fetchAndPopulateAirports : function (eventObject) {
    // Perform the service call only after atleast 3 characters are entered.
    if (3<=eventObject.text.length) {
      var amadeusServiceObject = kony.sdk.getCurrentInstance().getIntegrationService("Amadeus");
      var headers = {};
      var inputParameters = {"term":eventObject.text,"all_airports":true,"country":""};
      amadeusServiceObject.invokeOperation("Airport_Autocomplete",headers,inputParameters,fetchAndPopulateAirportsSuccessCallback.bind(this),fetchAndPopulateAirportsFailureCallback.bind(this));
    } else {
      return;
    }
    
    /**
     * @function fetchAndPopulateAirportsSuccessCallback
     *
     * This function is the success callback to the operation "Airport_Autocomplete" in the service "Amadeus".
     * In this function results are populated into the segment to show the Airports.
     *
     */
    function fetchAndPopulateAirportsSuccessCallback (response) {
      if (null !== response) {
        if (0 === response.opstatus) {
			if (response.Records.length>0) {
              this.view.slidingmenu.flxTargetContainer.segAirports.widgetDataMap = {"lblAirportName":"label","lblAirportCode":"value"};
              this.view.slidingmenu.flxTargetContainer.segAirports.setData(response.Records);
              this.view.slidingmenu.flxTargetContainer.segAirports.setVisibility(true);
            }          
        }
      }
    }

    /**
     * @function fetchAndPopulateAirportsFailureCallback
     *
     * This function is the failure callback to the operation "Airport_Autocomplete" in the service "Amadeus".
     * In this function error message is displayed as an alert.
     *
     */
    function fetchAndPopulateAirportsFailureCallback (error) {
      alert ("fetchAndPopulateAirportsFailureCallback: "+JSON.stringify(error));
    }   
  },
  
  /**
   * @function populateSelectedAirport
   *
   * This function will be invoked in the onRowClick event of the segment containing the airport list.
   * In this function we will populate the selected airport into either departure or return fields.
   *
   */
  populateSelectedAirport : function () {
    if (this.searchForDepartureAirport) {
      this.sourceAirport = this.view.slidingmenu.flxTargetContainer.segAirports.selectedRowItems[0];
      this.view.slidingmenu.flxTargetContainer.lblFrom.text = this.view.slidingmenu.flxTargetContainer.segAirports.selectedRowItems[0].value;
    } else if (this.searhForReturnAirport) {
      this.destinationAirport = this.view.slidingmenu.flxTargetContainer.segAirports.selectedRowItems[0];
      this.view.slidingmenu.flxTargetContainer.lblTo.text = this.view.slidingmenu.flxTargetContainer.segAirports.selectedRowItems[0].value;
    }
    this.hideAirportSearch();
  },
  
  /**
   * @function fetchAndPopulateFlights
   *
   * This function will be invoked in the onClick of the Search button in the flight search screen.
   * In this function we will invoke "Flight_Affiliate_Search" operation in "Amadeus" service configured in Fabric.
   * And the results are populated into the segment to show the available flights.
   *
   */
  fetchAndPopulateFlights : function () {
    // Validate from and to locations
    if ("From" === this.view.slidingmenu.flxTargetContainer.lblFrom.text || "To" === this.view.slidingmenu.flxTargetContainer.lblTo.text) {
      alert ("Please select valid From and To locations.");
      return;
    }
    if (this.view.slidingmenu.flxTargetContainer.lblFrom.text === this.view.slidingmenu.flxTargetContainer.lblTo.text) {
      alert ("Departure and Return locations cannot be the same.");
      return;
    }

    // Validate departure and return dates
    if (this.view.slidingmenu.flxTargetContainer.calDeparture.date === null || 
        this.view.slidingmenu.flxTargetContainer.calDeparture.date === "" || 
        this.view.slidingmenu.flxTargetContainer.calReturn.date === null || 
        this.view.slidingmenu.flxTargetContainer.calReturn.date === "") {
      alert ("Please select valid Departure and Return dates.");
      return;
    }
    if (this.view.slidingmenu.flxTargetContainer.calDeparture.date > this.view.slidingmenu.flxTargetContainer.calReturn.date) {
      alert ("Departure date can not be greater than return date.");
      return;
    }
    
    // Validate number of passengers
    if (0 === this.numberOfAdultPassengers) {
      alert ("Please select atleast 1 adult traveller.");
      return;
    }

    var amadeusServiceObject = kony.sdk.getCurrentInstance().getIntegrationService("Amadeus");
    var headers = {};
    var inputParameters = {        
      	"origin":this.view.slidingmenu.flxTargetContainer.lblFrom.text,
      	"destination":this.view.slidingmenu.flxTargetContainer.lblTo.text,
        "return_date":this.view.slidingmenu.flxTargetContainer.calReturn.date.replace("/","-").replace("/","-"),
      	"departure_date":this.view.slidingmenu.flxTargetContainer.calDeparture.date.replace("/","-").replace("/","-"),
        "adults":this.numberOfAdultPassengers,
      	"children":this.numberOfChildPassengers,
      	"infants":this.numberOfInfantPassengers,
        "currency":"USD"
    };
    //alert(JSON.stringify(inputParameters));
    amadeusServiceObject.invokeOperation("Flight_Affiliate_Search",headers,inputParameters,fetchAndPopulateFlightsSuccessCallback.bind(this),fetchAndPopulateFlightsFailureCallback.bind(this));
    
    /**
     * @function fetchAndPopulateFlightsSuccessCallback
     *
     * This function is the success callback to the operation "Flight_Affiliate_Search" in the service "Amadeus".
     * In this function results are populated into the segment to show the available flights.
     *
     */
    function fetchAndPopulateFlightsSuccessCallback (response) {
      var flightsCount=0;
      var totalPrice=0;
      var currency="";
      var airLine="";
      var outBounddeparts_at="";
      var outBoundarrives_at="";
      var outBoundduration="";
      var outBoundorigin="";
      var outBounddestination="";
      var inBounddeparts_at="";
      var inBoundarrives_at="";
      var inBoundduration="";
      var inBoundorigin="";
      var inBounddestination="";
      var flightObj={};
      var segFlightList=[];
      var icon="";
      var origin=this.view.slidingmenu.flxTargetContainer.lblFrom.text;
      var destination=this.view.slidingmenu.flxTargetContainer.lblTo.text;
      if (response !== null && response.opstatus === 0) {
        flightsCount=response.results.length;
        
        this.view.slidingmenu.flxTargetContainer.lblNumberOfFlights.setVisibility(true);
        if(flightsCount === 0){
          this.view.slidingmenu.flxTargetContainer.lblNumberOfFlights.text = "No flights found from "+origin+" To "+destination;
          return;
        }else if(flightsCount==1){
          this.view.slidingmenu.flxTargetContainer.lblNumberOfFlights.text = ""+flightsCount+" flight found from "+origin+" To "+destination;
        }else{
          this.view.slidingmenu.flxTargetContainer.lblNumberOfFlights.text = ""+flightsCount+" flights found from "+origin+" To "+destination;
        }
        this.flightList=response.results;
        this.logo="https://api.connect.travelaudience.com"+response.meta.carriers.WX.logos.medium;
        this.airlineName=response.meta.carriers.WX.name;
        
        if (flightsCount>0) {
          for(var i=0;i<flightsCount;i++){
            try{
              totalPrice=response.results[i]["fare"]["total_price"];
              currency=response.results[i]["fare"]["currency"];
              airLine=response.results[i]["airline"];
              icon=response.meta.carriers.WX.logos.medium;
              if(response.results[i]["outbound"]!==undefined){
                outBounddeparts_at=this.getTime(response.results[i]["outbound"]["flights"][0]["departs_at"]);
                outBoundarrives_at=this.getTime(response.results[i]["outbound"]["flights"][0]["arrives_at"]);
                outBoundduration=response.results[i]["outbound"]["duration"];
                outBoundorigin=response.results[i]["outbound"]["flights"][0]["origin"]["airport"];
                outBounddestination=response.results[i]["outbound"]["flights"][0]["destination"]["airport"];
                flightObj["lblDepartureTime"]={"text":outBounddeparts_at};
                flightObj["lblArrivalTime"]={"text":outBoundarrives_at};
                flightObj["lblDuration"]={"text":outBoundduration};
                flightObj["lblSource"]={"text":outBoundorigin};
                flightObj["lblDestination"]={"text":outBounddestination};
              }
              if(response.results[i]["inbound"]!==undefined){
                inBounddeparts_at=this.getTime(response.results[i]["inbound"]["flights"][0]["departs_at"]);
                inBoundarrives_at=this.getTime(response.results[i]["inbound"]["flights"][0]["arrives_at"]);
                inBoundduration=response.results[i]["inbound"]["duration"];
                inBoundorigin=response.results[i]["inbound"]["flights"][0]["origin"]["airport"];
                inBounddestination=response.results[i]["inbound"]["flights"][0]["destination"]["airport"];
                flightObj["lblReturnDepartureTime"]={"text":inBounddeparts_at};
                flightObj["lblReturnDuration"]={"text":inBoundduration};
                flightObj["lblReturnArrivalTime"]={"text":inBoundarrives_at};
                flightObj["lblReturnSource"]={"text":inBoundorigin};
                flightObj["lblReturnDestination"]={"text":inBounddestination};
              }else{
                flightObj["flxDivider2"]={"isVisible":false}
              }

              flightObj={
                "imgAirlinesIcon":{"src":"https://api.connect.travelaudience.com"+icon},
                "lblAirlinesName":{"text":airLine},
                "lblPrice":{"text":"$"+" "+totalPrice},
              };
              segFlightList.push(flightObj);
            }catch(excp){
              alert(JSON.stringify(excp));
            }
          }
          this.view.slidingmenu.flxTargetContainer.segFlights.removeAll();
          this.view.slidingmenu.flxTargetContainer.segFlights.addAll(segFlightList)
          this.view.slidingmenu.flxTargetContainer.segFlights.setVisibility(true);
        }        
      }
    }
    
    /**
     * @function fetchAndPopulateFlightsFailureCallback
     *
     * This function is the failure callback to the operation "Flight_Affiliate_Search" in the service "Amadeus".
     * In this function error message is displayed as an alert.
     *
     */
    function fetchAndPopulateFlightsFailureCallback (error) {
      alert ("fetchAndPopulateFlightsFailureCallback: "+JSON.stringify(error));
    }
  },
  
  /**
   * @function getTime
   *
   * This is a utility function to format the time. 
   *
   */
  getTime : function(timeString){
    var str="";
    var date1=new Date(timeString);
    var time=date1.toLocaleTimeString();
    time=(time.split(" "))[0];
    time=time.split(":");
    var hr=time[0];
    var min=time[1];
    if(hr>12){
      hr=hr%12;
      str="PM";
    }else{
      str="AM";
    }
    var timeString=hr+":"+min+" "+str;
    return timeString;
  },
  
  /**
   * @function onFlightSelection
   *
   * This function will be invoked in the onRowClick of the segment in FindFlights screen.
   * In this function we will navigate the user to the FlightDetails screen, showing the details of the selected flight.
   *
   */
  onFlightSelection : function () {
    var slectedRow=this.view.slidingmenu.flxTargetContainer.segFlights.selectedRowIndex[1];
    slectedRow++;
    var flightObj=this.flightList[slectedRow];
    
    var navObj=new kony.mvc.Navigation("frmFlightDetails");
    flightObj["source"]=this.sourceAirport;
    flightObj["destination"]=this.destinationAirport;
    flightObj["flightLogo"]=this.logo;
    flightObj["airlineName"]=this.airlineName;
    flightObj.numberOfAdultPassengers=this.numberOfAdultPassengers;
    flightObj.numberOfChildPassengers=this.numberOfChildPassengers;
    flightObj.numberOfInfantPassengers=this.numberOfInfantPassengers;

    navObj.navigate(flightObj);
  }
 });