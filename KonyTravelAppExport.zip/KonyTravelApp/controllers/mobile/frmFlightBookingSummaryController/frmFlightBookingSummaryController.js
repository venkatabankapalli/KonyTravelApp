define({ 

  //Type your controller code here 
  flightObj:{},
  
  /**
   * @function slidingMenuItemClickCallback
   * 
   * This function will be invoked when a menu item is clicked in the sliding menu. 
   * This function is associated to onMenuItemClick action of slidingmenu component.
   * This function will navigate the user to respective form based on the index of the clicked menu item.
   *
   * @param indexOfTheClickedMenuItem 
   */
  onMenuItemClickCallback : function (indexOfTheClickedMenuItem) {

    var formName = "";
    if (0 === indexOfTheClickedMenuItem[0]) {
      formName = "frmTrip";
    } else if (1 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindFlight";
    } else if (2 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindHotel";
    } else if (3 === indexOfTheClickedMenuItem[0]) {
      formName = "frmFindCar";
    } else if (4 === indexOfTheClickedMenuItem[0]) {
      formName = "frmPackage";
    } else if (5 === indexOfTheClickedMenuItem[0]) {
      formName = "frmInspireMe";
    }
    var navigationObject = new kony.mvc.Navigation(formName);
    navigationObject.navigate();
  },
  
  /**
   * @function
   *
   */
  onNavigate : function (data) {
    if(data === null || data === undefined) {
      return;
    }
    this.flightObj=data;
    this.view.slidingmenu.flxTargetContainer.lblAirlineName.text=data.airline;
    this.view.slidingmenu.flxTargetContainer.lblOutboundFlightID.text=data.outbound.flights[0].marketing_airline+" "+data.outbound.flights[0].flight_number;
    this.view.slidingmenu.flxTargetContainer.lblDepartureAirportOutboundFlight.text=data.outbound.flights[0].origin.airport;
    this.view.slidingmenu.flxTargetContainer.lblArrivalAirportOutboundFlight.text=data.outbound.flights[0].destination.airport;
    if(data.inbound===null || data.inbound===undefined){
      this.view.slidingmenu.flxTargetContainer.flxLine2.setVisibility(false);
      this.view.slidingmenu.flxTargetContainer.flxFlight2.setVisibility(false);
    }else{
      this.view.slidingmenu.flxTargetContainer.lblInboundFlightID.text=data.inbound.flights[0].marketing_airline+" "+data.inbound.flights[0].flight_number;
      this.view.slidingmenu.flxTargetContainer.lblDepartureAirportInboundFlight.text=data.inbound.flights[0].origin.airport;
      this.view.slidingmenu.flxTargetContainer.lblArrivalAirportInboundFlight.text=data.inbound.flights[0].destination.airport;
    }
    this.view.slidingmenu.flxTargetContainer.lblAdult.text=data.adultTravellerNames;
    this.view.slidingmenu.flxTargetContainer.lblChild.text=data.childTravellerNames;
    this.view.slidingmenu.flxTargetContainer.lblInfant.text=data.infantTravellerNames;
    this.view.slidingmenu.flxTargetContainer.lblFare.text="$ "+data.fare.total_price;
  },

  /**
   * @function getReadableDate
   *
   * Utility function to get the readable date from a date string
   *
   */
  getReadableDate : function(dateString){
    var d = new Date(dateString);
    dateString = d.toDateString();
    return dateString;
  },
  
  /**
   * @function getTime
   *
   * Utility function to get the time from a time string
   *
   */
  getTime : function(timeString){
    var str="";
    var date1=new Date(timeString);
    var time=date1.toLocaleTimeString();
    time=(time.split(" "))[0];
    time=time.split(":");
    var hr=time[0];
    var min=time[1];
    if(hr>12){
      hr=hr%12;
      str="PM";
    }else{
      str="AM";
    }
    timeString=hr+":"+min+" "+str;
    return timeString;
  },
  
  /**
   * @function
   *
   */
  confirm : function () {
    var basicConf = {
      message:"Do you like to proceed with the booking?",
      alertType: constants.ALERT_TYPE_CONFIRMATION,
      alertTitle:'"Booking"',yesLabel:"YES",
      noLabel:"NO",alertIcon: "kony_travel_logo.png", alertHandler: handle2
    };
    var self=this;
    //Defining pspConf parameter for alert
    var pspConf = {};
    //Alert definition
    kony.ui.Alert(basicConf,pspConf);
    function handle2(response){
      kony.print(JSON.stringify(response));
      response = JSON.stringify(response);
      if(response === "true"){
        self.bookFlight();
      }
      else{
        return;
      }
    }
  },
  
  /**
   * @function
   *
   */
  bookFlight : function() {
    var self=this;
    var email="venkata.bankapalli@kony.com";
    var data=this.flightObj;
    var inputParam={
      "email": email,
      "airline_name":data["airlineName"],
      "onward_source": data.outbound.flights[0].origin.airport,
      "onward_destination": data.outbound.flights[0].destination.airport,
      "return_source": data.inbound.flights[0].origin.airport,
      "return_destination": data.inbound.flights[0].destination.airport,
      "onward_departure": data.outbound.flights[0].departs_at,
      "onward_arrival": data.outbound.flights[0].arrives_at,
      "outbound_airline":data.outbound.flights[0]["operating_airline"],
      "outbound_airline_number":data.outbound.flights[0]["flight_number"],
      "flight_logo": data["flightLogo"],
      "adults": data.adultTravellerNames,
      "child": data.childTravellerNames,
      "infant": data.infantTravellerNames,
      "fare": data.fare.currency+" "+data.fare.total_price,
      "outbound_duration": data.outbound.duration,
      "CreatedBy": "",
      "LastUpdatedBy": "",
      "CreatedDateTime": "",
      "LastUpdatedDateTime": "",
      "SoftDeleteFlag": false
    }
    if(data.inbound==undefined){
      inputParam["return_departure"]="";
      inputParam["return_arrival"]="";
      inputParam["inbound_duration"]="";
    }else{
      inputParam["return_departure"]=data.inbound.flights[0].departs_at;
      inputParam["return_arrival"]=data.inbound.flights[0].arrives_at;
      inputParam["inbound_airline"]=data.inbound.flights[0]["operating_airline"];
      inputParam["inbound_airline_number"]=data.inbound.flights[0]["flight_number"];
    }
    
    var controllerScope=this;
    try
    {
      kony.model.ApplicationContext.showLoadingScreen("Flight Booking InProgress ...");
      kony.model.ApplicationContext.createModel(
        										"BookingObject",
        										"FlightBookingObjectService", 
        										{"access": "online"},
                                                {"getFromServer":true},
        										successCallbackForCreateModel,
        										errorCallBackForCreateModel
      											);
    }
    catch(exp)
    {
      kony.print("#### Exception while creating data model ####"+JSON.stringify(exp));
      alert("#### Exception while creating data model ####"+JSON.stringify(exp));
      kony.model.ApplicationContext.dismissLoadingScreen();
    }
    
    /**
     * @function successCallbackForCreateModel
     *
     * @param dataModel 
     */
    function successCallbackForCreateModel(dataModel) 
    {
      //alert ("successCallbackForCreateModel: "+JSON.stringify(inputParam));
      var userDataObject = new kony.sdk.dto.DataObject("BookingObject");
      userDataObject.setRecord(inputParam);
      dataModel.create(
        				{dataObject: userDataObject}, 
        				/**
        				 * @function successCallbackForCreateOperation
        				 *
        				 * @param successResponse 
        				 */
        				function(successResponse) 
        				{
                          kony.print("$$$$$$$$ booking success $$$$$$$"+JSON.stringify(successResponse));
                          kony.model.ApplicationContext.dismissLoadingScreen();
                          //alert("booking success! "+JSON.stringify(successResponse));
                          try{
                            controllerScope.sendNotification();
                            var navObj=new kony.mvc.Navigation("frmTrip");
                            navObj.navigate();
                          }catch(excp){
                            alert("#### Exception occured while navigating to frmFindFlight ####");
                            kony.print("#### Exception occured while navigating to frmFindFlight ####");
                          }
                        }, 
        				/**
        				 * @function errorCallbackForCreateOperation
        				 *
        				 * @param errorResponse 
        				 */
        				function(errorResponse) 
        				{
                          kony.model.ApplicationContext.dismissLoadingScreen();
                          alert("booking failed! "+JSON.stringify(errorResponse));
                          kony.print("$$$$$$$$$$$$$$$ booking failed errorResponse $$$$$$$$ "+JSON.stringify(errorResponse.getRootErrorObj()));
                        }
      				);
    }
    /**
     * @function errorCallBackForCreateModel
     *
     * @param err 
     */
    function errorCallBackForCreateModel(err) 
    {
      kony.model.ApplicationContext.dismissLoadingScreen();
      kony.print("$$$$$$$$$$$ err  $$$$$$$$$ "+JSON.stringify(err.getRootErrorObj()));
    }
  },
  
  /**
   * @function
   *
   */
  sendNotification:function() {
    var konyIntegrationSvcObj = null;
    var sdkClient = null;
    var controllerScope = this;
    var operationName = "sendNotification";
    var headers = {};

    var ksid=kony.store.getItem("KSID");
    var arrayKSID1=[{"ksid": ksid}];
    var d = new Date();
    var min=d.getMinutes();
    d.setMinutes(min+2);
    var m=d.getTime();
    var inputParams = {
      //"title": "Travel Reminder",
      "data" : "Reminder for your travel scheduled on "+d.toDateString(),
      "ksid" : ksid,//JSON.stringify(arrayKSID1),
      "appId":"fc0a09ad-f114-48ea-99d2-355a01069a40", //KMSAPPID
      "userid":kony.store.getItem("USER_ID"),
      "password":"KonY@1234$"
    };

    try
    {
      kony.model.ApplicationContext.showLoadingScreen("Sending notification.........");
      sdkClient = kony.sdk.getCurrentInstance();
      if(sdkClient !== null)
      {
        konyIntegrationSvcObj = sdkClient.getIntegrationService("Notification");
        if(konyIntegrationSvcObj !== null)
        {
          alert (JSON.stringify(inputParams));
          konyIntegrationSvcObj.invokeOperation(operationName,headers,inputParams,function(successResponse){
            kony.model.ApplicationContext.dismissLoadingScreen();
            //alert("Push Message sent successfully! "+JSON.stringify(successResponse));
          },function(errorResponse){
            kony.model.ApplicationContext.dismissLoadingScreen();
            alert("In failure callback"+JSON.stringify(errorResponse));
          });
        }
        else
        {
          kony.model.ApplicationContext.dismissLoadingScreen();
          alert("Error in invoking the operation");
        }
      }
      else
      {
        kony.model.ApplicationContext.dismissLoadingScreen();
        alert("Unable to get the instance of the MF App");
      }
    }catch(exception)
    {
      kony.model.ApplicationContext.dismissLoadingScreen();
      alert("Unable to invoke operation");
    }
  },  
 });