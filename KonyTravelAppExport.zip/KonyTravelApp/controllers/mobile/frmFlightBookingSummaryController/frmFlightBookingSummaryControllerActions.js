define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_f62a87b6808f44c992135fbd1d3a148e: function AS_Button_f62a87b6808f44c992135fbd1d3a148e(eventobject) {
        var self = this;
        return self.travellerDetails.call(this);
    },
    AS_Button_d19326c92bb34903bd4607e37eb97211: function AS_Button_d19326c92bb34903bd4607e37eb97211(eventobject) {
        var self = this;
        this.confirm();
    },
    AS_UWI_e22b09e8ceff44b991b4bfbe5cdfbe97: function AS_UWI_e22b09e8ceff44b991b4bfbe5cdfbe97(menuindex) {
        var self = this;
        return self.onMenuItemClickCallback.call(this);
    }
});