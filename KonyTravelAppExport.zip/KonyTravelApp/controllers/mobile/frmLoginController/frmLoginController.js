define({ 

  //Type your controller code here 
  /**
   * @function loginSuccess
   *
   * This function will be invoked in the onLoginSuccess event of Login component
   *
   */
  loginSuccess:function() {
    var emailID=this.view.login.getUsername();
    kony.store.setItem("USER_ID", emailID);
    try {
      var ksid=kony.store.getItem("KSID");
      if(ksid===null||ksid===undefined) {
        kony.print("#### ksid not found ####");
        this.pushNotificationSetup();
      }else{
        var navObj=new kony.mvc.Navigation("frmTrip");
        navObj.navigate();
      }
    }catch(excp){
      kony.print("#### Exception occured in loginSuccess ####");
      mLogger.error("#### Exception occured in loginSuccess ####"+excp);
    }
    //}
  },

  /**
   * @function setPushCallbacksAndroid
   *
   * This function is used to set the callback functions for the various events which occur during push notifications
   *
   */
  setPushCallbacksAndroid : function() {
    var controllerScope=this;
    kony.push.setCallbacks({
      onsuccessfulregistration: this.regSuccessAndroidCallback, onfailureregistration: this.regFailureAndroidCallback,
      onlinenotification:this.onlinePushNotificationAndroidCallback, offlinenotification: this.offlinePushNotificationAndroidCallback,
      onsuccessfulderegistration: this.unregSuccessAndroidCallback, onfailurederegistration:this.unregFailureAndroidCallback 
    });
  },
  
  /**
   * @function pushNotificationSetup
   *
   * This function is used to invoke setPushCallbacks and then to invoke registerForPushNotifications 
   *
   */
  pushNotificationSetup : function() {
    var controllerScope=this;
    var devName = kony.os.deviceInfo().name;
    if(devName=="android"){
      controllerScope.setPushCallbacksAndroid();
      controllerScope.registerForPushNotificationsOnAndroid();
    }
    //else if((devName=="iPhone")||(devName=="iPhone Simulator")||(devName=="iPad")||(devName=="iPad Simulator")){
    //  controllerScope.callbackiPhoneSetCallbacks();
    //  controllerScope.callbackiPhoneRegister();
    //}
  },  
  
  /**
   * @function registerForPushNotificationsOnAndroid
   *
   * This function is used to register with GCM
   *
   */
  registerForPushNotificationsOnAndroid : function() {
    var senderId = KMSPROP.senderID;
    //alert(senderId);
    var configToRegister = {senderid:senderId};
	kony.push.register(configToRegister);
  },
  
  /**
   * @function unregFailureAndroidCallback
   *
   * This function is a callback function which will get invoked when deregistration for push noticiations fail
   *
   * @param errormsg 
   */
  unregFailureAndroidCallback : function(errormsg) {
    kony.application.dismissLoadingScreen();
  },

  /**
   * @function
   *
   * This function is a callback function which will get invoked when deregistration for push noticiations is successful
   *
   */
  unregSuccessAndroidCallback : function() {
    kony.application.dismissLoadingScreen();
  },
  
  /**
   * @function
   *
   * This function is invoked to handle offline push notification
   *
   * @param msg 
   */
  offlinePushNotificationAndroidCallback : function(msg) {
    if(msg["content-available"]!=1){
      displayPush(msg);
    }else{
      alert("Silent Push Received");
    }
  },

  /**
   * @function
   *
   * This function is invoked to handle online push notification
   *
   * @param msg 
   */
  onlinePushNotificationAndroidCallback : function(msg) {
    if(msg["content-available"]!=1) {
      displayPush(msg);
    }else{
      alert("Silent Push Received");
    }
  },

  /**
   * @function unregFailureAndroidCallback
   *
   * This function is a callback function which will get invoked when registration for push noticiations fail
   *
   * @param errormsg 
   */
  regFailureAndroidCallback: function(errormsg) {
    kony.application.dismissLoadingScreen();
    alert("regFailureAndroidCallback: "+JSON.stringify(errormsg));
  },
  
  /**
   * @function unregFailureAndroidCallback
   *
   * This function is a callback function which will get invoked when registration for push noticiations success.
   * After successful registration with GCM, we subscribe the application with KMS by invoking pushSubscription
   *
   * @param errormsg 
   */
  regSuccessAndroidCallback : function(regId) {
    //alert("regSuccessAndroidCallback: "+regId);
    var controllerScope=this;
    this.pushSubscription(regId,"android");
  },
  
  /**
   * @function 
   *
   * After successful registration with GCM, app need to be subscribed with KMS.
   *
   * @param regId 
   * @param osType 
   */
  pushSubscription : function(regId,osType) {
    var controllerScope = this; 
    KMSPROP.deviceId=kony.os.deviceInfo().deviceid;
    var messagingSvc = kony.sdk.getCurrentInstance().getMessagingService();
    var emailID=kony.store.getItem("USER_ID");
    kony.model.ApplicationContext.showLoadingScreen("subscribing for push...");
    messagingSvc.register(osType, KMSPROP.deviceId, regId, emailID, successCallbackForSubscribe, failureCallbackForSubscribe);
    function successCallbackForSubscribe(res){   
      kony.store.setItem("KSID", res.id);
      KMSPROP.ksId = res.id;
      kony.print("ksid is:-- "+KMSPROP.ksId);
      var navObj=new kony.mvc.Navigation("frmTrip");
      navObj.navigate();
      kony.application.dismissLoadingScreen();
    }
    function failureCallbackForSubscribe(err){
      kony.print(JSON.stringify(err));
      kony.application.dismissLoadingScreen();
    }
  },

});