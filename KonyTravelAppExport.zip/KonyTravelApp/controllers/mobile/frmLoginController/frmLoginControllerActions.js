define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_UWI_ic552391db27406e8f8400a273a3a0fc: function AS_UWI_ic552391db27406e8f8400a273a3a0fc(response) {
        var self = this;
        this.loginSuccess();
    }
});